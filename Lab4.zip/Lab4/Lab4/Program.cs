﻿using Lab4;


// z.2
// Napisz program wykorzystując polimorfizm, który będzie sprawdzał czy nauczyciel może wypuścić do domu uczniów swojej klasy bez opieki dorosłego


//Teacher teacher = new Teacher { FirstName = "Jan", LastName = "Nowak", TitleScientific= "Mgr."}

//List<(string FirstName, string LastName, string PESEL)> uczniowie - new List<(string, string, string)>
//{
//    ("Janina", "Nowak", "01234567")
//    ("Adam", "Nowak", "89012345")
//    ("Krzysztof", "Kowalski", "67890123")
//    ("Andrzej", "Kwiatkowski", "45678901")
//};

//foreach (var (firstName, LastName, PESEL) in uczniowie)
//{
//    Student student = new Student() { FirstName = firstName, LastName = LastName, PESEL = PESEL, School = "SP 1", HecanGoHomeAlone = false };
//    teacher.AddStudent(student);
//}
//teacher.WhichStudentCanGoHomeAlone(DateTime.Now);